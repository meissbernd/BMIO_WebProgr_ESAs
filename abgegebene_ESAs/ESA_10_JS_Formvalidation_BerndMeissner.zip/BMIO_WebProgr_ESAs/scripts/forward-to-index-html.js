(function () {
    "use strict";

    console.clear();
    console.log("Start forward-to-index-html");

    setTimeout(() => {
        window.location.href = 'index.html';
    }, 3000);

})();